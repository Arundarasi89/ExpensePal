package layout;

import android.app.Activity;

public class graphs extends Activity {
}
