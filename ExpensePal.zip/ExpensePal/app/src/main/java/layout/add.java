package layout;

import androidx.fragment.app.Fragment;

/**
 * A simple {@link Fragment} subclass.
 */
public class add extends Fragment {

    public add() {
        // Required empty public constructor
    }

}
